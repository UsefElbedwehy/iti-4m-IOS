//
//  DoneViewController.h
//  ToDoList
//
//  Created by Uef on 30/12/2024.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DoneViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>

@end

NS_ASSUME_NONNULL_END
