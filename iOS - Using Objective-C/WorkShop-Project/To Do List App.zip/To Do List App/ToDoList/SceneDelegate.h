//
//  SceneDelegate.h
//  ToDoList
//
//  Created by Uef on 30/12/2024.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

