//
//  MiddleCollectionViewCell.swift
//  task2_CompositionalLayout
//
//  Created by Usef on 22/01/2025.
//

import UIKit

class MiddleCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var foodTitleLB: UILabel!
}
