//
//  BottomCollectionViewCell.swift
//  task2_CompositionalLayout
//
//  Created by Usef on 21/01/2025.
//

import UIKit

class BottomCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var priceLB: UILabel!
    @IBOutlet weak var titleLB: UILabel!
    @IBOutlet weak var descriptionLB: UILabel!
    
    
    @IBOutlet weak var addAction: UIButton!
}
