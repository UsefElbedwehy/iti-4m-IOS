//
//  TopCollectionViewCell.swift
//  task2_CompositionalLayout
//
//  Created by Usef on 21/01/2025.
//

import UIKit

class TopCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
}
