//
//  PaymentCell.swift
//  task2_CompositionalLayout
//
//  Created by Usef on 26/01/2025.
//

import UIKit

class PaymentCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
