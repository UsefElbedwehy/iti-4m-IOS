//
//  ViewController.swift
//  task2_CompositionalLayout
//
//  Created by Usef on 21/01/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

